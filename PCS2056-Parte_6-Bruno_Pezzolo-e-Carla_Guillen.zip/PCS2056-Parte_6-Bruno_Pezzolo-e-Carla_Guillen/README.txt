/* ======================================================================
 *	 		 	    PCS 2056 - Linguagens e Compiladores
 * ======================================================================
 *
 * Entrega final do Compilador Educaciional para a disciplina PCS 2056 
 * 
 * 		Autores:
 *     		Bruno Pezzolo dos Santos, 5948816
 *      	Carla Guillen Gomes, 5691366
 */

 O programa ENTRADA.txt representa o cálculo do fatorial de um número
 recebido como INPUT pelo usuário. O sistema espera o input do usuário
 e calcula o fatorial do número, imprimindo-o na tela.