/* =======================================================
 *	 		PCS 2056 - Linguagens e Compiladores
 * =======================================================
 *
 * semantic.c - Semantic Analyser
 *
 * Created on: 31/10/2011
 * 		Authors:
 *     		Bruno Pezzolo dos Santos, 5948816
 *      	Carla Guillen Gomes, 5691366
 *
 */

#ifndef SEMANTIC_H_
#define SEMANTIC_H_

#include <stdlib.h>
#include <stdio.h>

#include "semantic_actions.h"

void end_program();

#endif /* SEMANTIC_H_ */
