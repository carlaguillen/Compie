O compilador compila o código contido no arquivo ENTRADA.k e produz o arquivo de saída SAIDA.il
Para compilar o código fonte basta compilar todos os arquivos .c, ou seja, executar o código:
gcc *.c -o compilador